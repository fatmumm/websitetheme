window.addEventListener("beforeunload", function () {
  document.body.classList.add("animate-out");
});